# START HERE — Wayfarer v2.0

[Latest v2.0 package](https://drive.google.com/drive/folders/1lQ0g_4T98h66YFm50msS7zSRJbz01Qb5) · [Release history](https://drive.google.com/drive/folders/1DWyFndpFuCwmb8chxIj0QJw-wPLjWqEe) · [Verification evidence](https://drive.google.com/drive/folders/19aiheEP8VMKlwUYJnFewFIXGSORmdSLl)

Use the v2.0 hardened candidate ZIP in Latest. Extract it, use Node 24.19.x, run `npm ci`, then `npm start`, and open http://localhost:8081. Source, built client assets, tests, release notes and verification reports are included. `npm test` rebuilds and checks the release.

The v1.10–v1.14 packages were already saved; their scattered placements made them difficult to find. Root release files now live in Release history. The previous guide is labeled HISTORICAL in Governance / Validation and handoffs.

| Folder | Purpose |
| --- | --- |
| 00_GOVERNANCE | Validation, handoffs and deployment guidance |
| 01_CANONICAL_BUILD | Latest Wayfarer v2.0, existing build archives and source/config |
| 02_DESIGN_REFERENCES | Design references |
| 03_VISUAL_REFERENCES | Visual references |
| 04_SOURCE_ARCHIVES | Historical Wayfarer and other project source archives |
| 90_QUARANTINE | Existing uncertain material retained for review |
| 91_CHECKSUMS | Integrity records |
| 99_SUPERSEDED_OR_DUPLICATE | Previously classified material retained |

The entire supplied subtree was cataloged: 1,018 original unique items, all preserved, with 26 verified moves. Established category placements were retained and indexed. See the full index and organization evidence in Verification. Metadata/name matches are not proof of byte-identical duplicates.

v2.0 includes six earned PolyCodex skill trials, strict server/save contracts and Xam's varied 77-activity test controller. 438 tests passed; the fresh Xam simulation completed 75/77 activities with no failures. Full-health food/potion refusals account for the remaining two. Physical phone/PC visual review is pending.
