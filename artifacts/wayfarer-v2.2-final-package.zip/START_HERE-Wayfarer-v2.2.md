# START HERE — Wayfarer v2.2

[Latest v2.2](https://drive.google.com/drive/folders/12FojwFkWBIW5lUZUjqPYx-mjyZx5HZN4) · [Preserved v2.1](https://drive.google.com/drive/folders/1lQ0xg9GQoXLtmMJakZVSLh_pAJUJ7aTB) · [Preserved v2.0](https://drive.google.com/drive/folders/1lQ0g_4T98h66YFm50msS7zSRJbz01Qb5)

Extract the v2.2 harvest/bank candidate ZIP. With Node 24.19.x, run `npm ci`, then `npm start`, and open http://localhost:8081. `npm test` rebuilds and tests the source. Retain runtime data and match client/server versions.

Skills → Named trees, fish & ore → select a resource → Find resource → Harvest. Six trees, six fish and seven ores have individual level gates, named outputs and XP rewards. Stay nearby during timed gathering. Resources deplete and regrow.

Backpack → Personal bank at Halden: search, 1/5/10/X/all/all-but-one, items/notes, placeholders, ordering, deposit backpack and deposit equipment. Notes must be banked before gameplay use. Named banked materials can be converted to existing workshop resources. A 28-slot harvest backpack accompanies the existing resource/supply/cave/equipment pouches.

Quest → Cave instances reaches the existing shared basements, cellar, keep and mine. Raised trapdoor lids and ladders mark the outdoor and nested portals. Two fenced gardens add bushes, plants and permanently open gate passages. Previous v2.1 scenery, joined water, ramps and cape details remain.

V2.2-RELEASE-NOTES.md and V2.2-VERIFICATION.md document the changes and results. Source, built assets, tests and reports are inside the ZIP. Phone/PC visual and GPU review remains pending. Xam's existing 77-activity schedule is retained; dedicated tests exercise the new catalog and bank.

The prior Drive organization is retained. All 1,018 original item IDs were preserved in that pass; no duplicates were deleted. Previous builds remain available.
