# Wayfarer v1.9 — Flourishing Realm candidate

This is a visual continuation of v1.8, preserving the authoritative 20 Hz realm, persistence, skilling, Xam protections and interior routes.

- Trees retain their original solid trunk collider while gaining rooted moss, branches and layered canopy colour variants. Rocks retain their original solid bounds while gaining moss caps, fissures and scattered pebbles.
- A deterministic dry-land dressing pass places at most 144 flower, fern, mushroom, gravel, soil and driftwood clusters across the expanded realm. Support surfaces, paths, stairs and landing spaces are reserved. Steep and wet terrain is rejected.
- Decorative fish and animated surface ripples use at most eight surveyed deep-water positions away from support surfaces. They have no collision, picking, combat, drops or authoritative reward state. Deep water is still inaccessible to players.
- Observatory, mushroom lodge and archive gain framed windows, masonry accents and entrance markers; room access and collision stay unchanged.
- Shared pixel material recipes now include soil, gravel, sand and brick alongside the existing eight kinds. New flora geometry is merged by material and quality tier; frame updates create no meshes. Balanced mode hides finer clusters and fish, and limits ripple visibility.

Simulation revision remains 19; scene revision is 9. No new deep-water travel, boat system, ports, species catalogue or stacked-floor physics is introduced by this pass. Existing wildlife and scenic mountains remain available.

Validation is documented in V1_9_VERIFICATION.md. GPU performance, appearance and touch usability require an actual mobile/desktop visual review; NullEngine checks are not a substitute for that review.
