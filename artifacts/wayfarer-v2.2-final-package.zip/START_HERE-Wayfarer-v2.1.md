# START HERE — Wayfarer v2.1

[Latest v2.1](https://drive.google.com/drive/folders/1lQ0xg9GQoXLtmMJakZVSLh_pAJUJ7aTB) · [Preserved v2.0](https://drive.google.com/drive/folders/1lQ0g_4T98h66YFm50msS7zSRJbz01Qb5) · [Older release history](https://drive.google.com/drive/folders/1DWyFndpFuCwmb8chxIj0QJw-wPLjWqEe)

Use the v2.1 landscape candidate ZIP. Extract it; with Node 24.19.x run `npm ci`, then `npm start`, and open http://localhost:8081. `npm test` rebuilds and checks the source. Match client/server and retain runtime data.

In game: Quest → Landscape & scenery → select a destination → Find scenery → Examine nearby. Cave instances remain in the Quest panel. v2.1 adds wells, fountain, tomato crates, occupied cages, nets, rods, feathers, ducks, ridge ramps, joined flowing 3D water, cave dressing, more defined buildings/stairs and sharper cape heraldry. Seeded randomization remains consistent across multiplayer peers.

443 tests passed. Fresh Xam simulation: 75/77 activities completed, no failures; two full-health consumption refusals expected. Source, built assets, tests, release notes and verification reports are inside the ZIP. Phone/PC visual review remains pending.

The previous Drive organization is retained: Governance, Canonical build, Design references, Visual references, Source archives, Quarantine, Checksums and Superseded/duplicate categories. All 1,018 original item IDs were preserved in that pass. v1.10–v1.14 were already saved and are now easier to find. No duplicates were deleted.
