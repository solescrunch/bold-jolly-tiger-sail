# v1.9 fresh verification — 2026-10-05

`npm test` passed 369 tests, zero failures, skips or cancellations. This includes strict TypeScript compilation, rebuilt browser bundles, multiplayer, persistence, replay, Xam protection, skilling and interior-navigation checks. Evidence: verification/v19-final-tests.log.

Three new tests cover deterministic bounded dry-land detail placement and support exclusion; merged mesh budgets, pause stability, quality switching and resource cleanup; and malformed descriptors rejected before allocation. New material pixel recipes are included in the existing deterministic distinct-tile test. The cleanup test retains Babylon’s scene-owned default material and requires every owned mesh, material and texture to be released. Standalone evidence: verification/v19-flourish-tests.log.

Contract and curriculum exports were refreshed. Simulation revision is 19; scene revision is 9. Package creation checks ZIP CRC and every SHA-256 manifest entry.

These are automated Node/Babylon NullEngine checks. Physical mobile/desktop appearance, GPU frame time and water transparency still need visual review. No deployment occurred; this is a candidate archive.
