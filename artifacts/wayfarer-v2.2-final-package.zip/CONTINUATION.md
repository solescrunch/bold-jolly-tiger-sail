# Wayfarer continuation — current v2.2

v2.2 named harvesting, settlement layers and banking complete. Production build passed. Full run: 470/471; one outdated v3 migration fixture corrected, then all five XP/migration tests passed. All 471 distinct tests verified, zero outstanding failures; production unchanged after full run. 28 new harvest/bank tests pass. Fresh Xam 100-minute simulation: 75/77 completed, 223 selections, zero failures; two full-health consumption refusals expected. Physical phone/PC visuals and GPU review pending.

Latest folder: https://drive.google.com/drive/folders/12FojwFkWBIW5lUZUjqPYx-mjyZx5HZN4 . Preserve v2.1/v2.0 and all original Drive items. Source remains working/wayfarer-v1.12.0; no Git repository. Version2.2.0, simulation27, scene16, save10, Xam brain2/tasks77.

src/harvest-content.ts: 19 named level-gated resources (6 trees,6 fish,7 ores), three-second jobs, stock3 shared nodes, minute regrowth, 28-slot named backpack. Production strict navigation curates all19 reachable sites; small custom test worlds use anchor fallback. Timed activity never persists offline. src/harvest-3d.ts supplies named geometry/depletion and shared water material.

src/realm-bank.ts: unified 36-item interface/adapters over existing ledgers; quantities, notes, placeholders, stable order, equipment storage, bulk preflight. Notes share harvest slots, require bank redemption, cannot become weapons. Typed banked materials convert1:1 to legacy workshop inputs. Existing pouches12/100/20/equipment retained. inventory.stored preserves the unique weapon invariant. Current schema10 strict, legacy1–9 migrate with new empty ledgers.

src/settlement-layers.ts adds two collision-backed fenced gardens with open gates/bushes/plants. Raised trapdoor geometry marks existing root/nested portals; five interior IDs unchanged. Prior v2.1 landscape114×112, flowing 3D water, ramps, scenery and cape improvements retained. Keep odd map minX15 for navigation-grid alignment and mine entrance reachability.

Skills→Named trees, fish & ore; Backpack→Personal bank at Halden; Quest→Cave instances. Gate toggle state and physical visuals are not verified features. The Xam schedule is unchanged; new catalog/bank have dedicated tests. See V2.2-RELEASE-NOTES.md, V2.2-VERIFICATION.md and verification/v220-*.
