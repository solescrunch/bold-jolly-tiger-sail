# Current candidate: Wayfarer v2.2 — Harvests, settlement layers & banking

See [V2.2-RELEASE-NOTES.md](V2.2-RELEASE-NOTES.md) and [V2.2-VERIFICATION.md](V2.2-VERIFICATION.md). Skills → Named trees, fish & ore; Backpack → Personal bank; Quest → Cave instances. Physical phone/PC visual review pending.

# Previous milestone: Wayfarer v2.1 — Landscape & layered scenery

See [V2.1-RELEASE-NOTES.md](V2.1-RELEASE-NOTES.md), [V2.1-VERIFICATION.md](V2.1-VERIFICATION.md) and [START_HERE-Wayfarer-v2.1.md](START_HERE-Wayfarer-v2.1.md). Quest → Landscape & scenery finds the new props and overlooks. 443 tests passed; physical visual review pending.

# Previous milestone: Wayfarer v2.0 — Hardened PolyCodex

See [V2.0-RELEASE-NOTES.md](V2.0-RELEASE-NOTES.md), [V2.0-VERIFICATION.md](V2.0-VERIFICATION.md) and [START_HERE-Wayfarer-v2.0.md](START_HERE-Wayfarer-v2.0.md). Six earned skill trials, strict save contracts and varied Xam coverage. 438 regression tests passed; physical visual review pending.

# Previous milestone: Wayfarer v1.14 — Xam coverage bot

See [V1.14-RELEASE-NOTES.md](V1.14-RELEASE-NOTES.md) and [V1.14-VERIFICATION.md](V1.14-VERIFICATION.md). Xam uses varied real gameplay loops, owns persistent XP and supplies, remains protected and examine-only, and provides read-only coverage diagnostics for developers and AI tools.

# Previous milestone: Wayfarer v1.13 — Connected Skilling

See [V1.13-RELEASE-NOTES.md](V1.13-RELEASE-NOTES.md) and [V1.13-VERIFICATION.md](V1.13-VERIFICATION.md). Connected seed/herb/potion, ore/bar/lantern, food, arrow/rune, prayer, agility and Slayer loops extend v1.12. Open Skills → Connected skills, Backpack, and Combat → Field bow & rune spells.

# Previous milestone: Wayfarer v1.12 — Venomcrag Mountain Mine

See [V1.12-RELEASE-NOTES.md](V1.12-RELEASE-NOTES.md) and [V1.12-VERIFICATION.md](V1.12-VERIFICATION.md). A mountainside portal leads to shared mining, cave lobster fishing and attackable scorpions. Venom coats an equipped weapon temporarily; inventory, drops, poison and XP are resolved by the server.

# Previous milestone: Wayfarer v1.11 — Layered Interior Worlds

See [V1.11-RELEASE-NOTES.md](V1.11-RELEASE-NOTES.md) and [V1.11-VERIFICATION.md](V1.11-VERIFICATION.md). Four shared worlds include nested basement/keep travel and cancellable chunk rendering with real loading progress.

# Previous milestone: Wayfarer v1.10 — Cave Instances

See [V1.10-RELEASE-NOTES.md](V1.10-RELEASE-NOTES.md) and [V1.10-VERIFICATION.md](V1.10-VERIFICATION.md). Use Quest → Cave instances to find an entrance, enter its separate map and return outside.

# Previous milestone: Wayfarer v1.9 — Flourishing Realm

See [V1_9_RELEASE.md](V1_9_RELEASE.md) and [V1_9_VERIFICATION.md](V1_9_VERIFICATION.md) for this visual pass and its verification limits.

# Wayfarer v1.8 · Curious Places candidate

Three original discoverable buildings, server-walked stair routes, raised rooms, a carved below-ground archive, local roof cutaways and destination/return controls. See V1.8-RELEASE-NOTES.md and V1.8-VERIFICATION.md. Matching client/server required: simulation revision 19, scene revision 8. Earlier notes below are historical.

# Wayfarer v1.7 · Skilling Curriculum candidate

Fifteen original level bands for all 23 skills; selectable gathering methods and material-consuming workshop commissions. The in-game Skills guide shows requirements, XP, costs, the next unlock and planned content clearly. See V1.7-RELEASE-NOTES.md, V1.7-SKILLING-DESIGN.md and V1.7-VERIFICATION.md. Matching client/server required: simulation revision 18, scene revision 7. Earlier notes below are historical.

# Wayfarer v1.6 · Gather, Pack, Bank candidate

Server-paced gathering with shared resource depletion/regrowth, visible resource props, a prominent Backpack tab, bank route guidance, 23 skill XP cards and authoritative health bars. See V1.6-RELEASE-NOTES.md and V1.6-VERIFICATION.md. Matching client/server required: simulation revision 17, scene revision 6. Earlier notes below are historical.

# Wayfarer v1.5 · Pixel-Etched Realm candidate

Shared procedural pixel surfaces, finer batched avatar accents and a server-confirmed casting echo. Maximum/High enable the detail; Balanced uses the simpler surfaces and disables cast echoes. See V1.5-RELEASE-NOTES.md and V1.5-VERIFICATION.md. This remains the faceted Babylon game, not a voxel-engine conversion. Matching v1.5 client and server use scene contract revision 5. Earlier release notes below are historical.

# Wayfarer v1.4 · Starlit Highlands candidate

A peaceful discovery trail on existing shared terrain, four cosmetic journal postcards, a device-local explorer title, and yak/panda/gull wildlife. See V1.4-RELEASE-NOTES.md and V1.4-VERIFICATION.md for scope and fresh evidence. The field journal does not award XP or transferable items. Scene contract revision is now 4; use matching v1.4 client and host. Earlier release notes below are historical.

# Wayfarer v1.3 mobile and PC candidate

This v1.3 candidate is derived from the intact Drive v1.2 Celestial PolyCodex package. See [v1.3 release notes](V1.3-RELEASE-NOTES.md) and [fresh verification](V1.3-VERIFICATION.md). It adds input comfort, orientation layout and server/release hardening. The v1.2 notes below document inherited features and historical verification.

A runnable, server-authoritative multiplayer realm derived from the supplied v0.9 rc.3 candidate. Version 1.2 makes the PolyCodex a server-owned magic/skilling system and expands Reedhaven/Ashfen with an original Celestial Observatory, Sunward Orchard, Prism Dew garden and Moonlight Cavern presentation layer. It does not mean a public host has been provisioned or every planned MMO feature is complete.

## Run locally

Use Node 24.19.x. From this folder:

```sh
npm ci
npm run build
npm start
```

Open `http://127.0.0.1:8081`. Your guest character is saved in `runtime/realm.sqlite`; the browser holds its signed identity cookie. A separate browser profile represents another player. Two tabs in the same browser profile share an identity, and only one can join at a time. Clearing cookies loses access to that guest character; account recovery and cross-device login are not implemented.

## Publish with HTTPS

The package includes a Docker image build, Docker Compose stack, and Caddy HTTPS gateway. On an always-on Linux host with Docker Compose, point your domain at the host, allow inbound TCP 80/443 and optionally UDP 443, then:

```sh
cp .env.example .env
# Set DOMAIN to your real hostname and EMAIL to your certificate contact.
docker compose config
docker compose up -d --build
```

Visit `https://YOUR_DOMAIN`. The game server has no published direct port. Player data and certificates use persistent Docker volumes. Read [DEPLOYMENT.md](DEPLOYMENT.md) for verification, backup, restore, upgrades, configuration, and hosting boundaries. A domain and persistent host are required; neither was created during this release.

## v1.2 Celestial PolyCodex additions

- Server-authoritative 12-node PolyCodex casting with range checks, tick cooldown, persistence and Magic/Runecrafting XP.
- Six one-use resonance attunements that are consumed only by matching successful authoritative skilling/combat actions.
- Original procedural Celestial Observatory, dodecahedral Codex, Sunward Orchard, Prism Dew garden and Moonlight Cavern art layers inspired by the supplied references.
- Moonlight Cavern presentation includes cyan/violet crystals, timber walkways, moon pool, lanterns, glowshrooms, portal energy and an astral snail.
- Circular minimap/HUD now exposes the authoritative Codex point and server resonance state.
- Compatibility contract bumped to simulation revision 16 / scene revision 3; old clients fail closed instead of guessing new semantics.

The note/color/dodecahedral motif is fictional game design. It makes no medical or physical-science claim. Visual effects cannot mutate authoritative movement, collision, inventory, combat or XP. See [V1.2-CELESTIAL-EXPANSION.md](V1.2-CELESTIAL-EXPANSION.md), [ART-INSPIRATION-V1.2.md](ART-INSPIRATION-V1.2.md) and [V1.2-VERIFICATION.md](V1.2-VERIFICATION.md).

## Included gameplay

- A shared Willowglass Causeway, authoritative movement at 20 Hz, navigation, walking/jogging/running and energy.
- Quiet Tithe quest, equipment/inventory, the cooperative Lantern Warden, XP and bank state.
- Gathering systems and explicit practice drills across 23 skills. Practice drills are not complete implementations of every profession.
- Server-controlled protected Xam, persistent progress and continuous simulation even without human players.
- Babylon 3D rendering with a 2D fallback, articulated characters, NPCs, wildlife, weather, framed art, HUD settings and touch controls.
- ABC cape wind controls retained as cosmetic motion.

## Changes for v1.0

SQLite WAL transactions with full synchronization replace the production JSON save path. A separate SQLite OS lock prevents competing realm processes using one data directory and releases automatically after a crash. New guest profiles are created only when loading the game page, with bounded enrollment/request/upgrade rates. Public mode requires an exact HTTPS origin and enforces origin, Host, signed-cookie and duplicate-session checks. Secure/HttpOnly cookies, CSP, health checks, structured lifecycle logs, graceful shutdown, backup and legacy migration tools are included.

Default capacity is 16 human players plus Xam; configuration accepts 1–32 humans. The 16-player automated check verifies basic concurrent operation, not sustained load or a 32-player performance guarantee.

## Verification and limits

Fresh v1.2 evidence is in [V1.2-VERIFICATION.md](V1.2-VERIFICATION.md). In this sandbox, the dependency-independent authority/browser-interface graph passes focused strict TypeScript checking, the focused PolyCodex/authority/HUD/expansion suite passes 15/15, the broader dependency-independent regression set passes 87/87, and the checked-in Babylon bridge bundle passes syntax/marker checks. The authoritative runtime test confirms a PolyCodex cast is invisible before the tick and committed through the same 50 ms realm transaction as movement/gameplay.

This sandbox has Node 22.16.0 while the project requires Node 24.19.x, has no `node_modules`, and could not reach the npm registry. Therefore the full dependency-backed Babylon/PGlite/WebSocket build and complete test matrix were not rerun for v1.2. The v1.0 verification material remains historical baseline evidence, not proof of the new v1.2 code.

The supplied orchard, crystal-mine, enchanted-book, luminous-fauna, neon-observatory and saturated-landscape images now influence original procedural gameplay presentation layers. They are not copied world textures or shipped as proprietary scene assets. See [ART-INSPIRATION-V1.2.md](ART-INSPIRATION-V1.2.md). Physical iPhone/Android/GPU visual review, live DNS/TLS and public Internet end-to-end operation remain unverified here.

This remains one persistent small realm with guest identities. There is no multi-region/sharded authority, account recovery, PvP economy, signed native mobile app or public uptime guarantee. Shared encounter/world state resets at restart; player exports and Xam progress persist. Abrupt termination can lose the latest unsaved interval (one second by default); stopped servers award no offline XP. SQLite requires a reliable persistent local filesystem, not ephemeral function storage or a network filesystem shared by replicas.

Historical rc.3 source, release notes, prior evidence and the older rc.8 snapshot remain included as reference material. [verification/v09-rc3-README.md](verification/v09-rc3-README.md) contains the previous README. The current production entrypoint remains `tools/server.mjs`; historical servers are not deployed by Docker.
